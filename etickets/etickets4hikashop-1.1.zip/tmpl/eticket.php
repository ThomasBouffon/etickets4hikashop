<?php
/**
 * @package		ETickets4Hikashop
 * @version		1.1
 * @hikashopVersion	1.5.8-2.2
 * @author		Thomas Bouffon - thomas.bouffon@gmail.com
 * @copyright		(C) . All rights reserved.
 * @license		GNU/GPLv3 http://www.gnu.org/licenses/gpl-3.0.html
 */
defined('_JEXEC') or die('Restricted access');?>
 <h1>ET4H_SITE_NAME</h1>
 <h2>ET4H_EVENT_NAME</h2>
 <table style="width:100%;"><tr><td>
 <ul>
 <li>Place : ET4H_ADDRESS</li>
 <li>Date : ET4H_EVENTDATE</li>
 <li>Price : ET4H_PRICE &euro;</li>
 <li>Ticket # ET4H_TN</li>
 <li>Ticket Id ET4H_TICKETID</li>
 </ul>
 </td>
 <td height="150px">
ET4H_QRCODE
</td></tr></table>
<table width="70%" height=200px>
<tr><td>ET4H_BARCODE</td></tr>
</table>

